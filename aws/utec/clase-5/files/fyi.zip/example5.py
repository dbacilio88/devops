from datetime import datetime, timedelta
from airflow.decorators import dag, task
import pandas as pd

@dag(
    dag_id='example_taskflow_pandas',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2021, 1, 1),
    catchup=False,
    tags=['example', 'taskflow', 'pandas'],
)
def taskflow_pandas_example():
    @task
    def create_dataframe():
        # Create a DataFrame
        df = pd.DataFrame({
            'A': [1, 2, 3, 4],
            'B': [5, 6, 7, 8]
        })
        return df

    @task
    def manipulate_dataframe(df: pd.DataFrame):
        # Add a new column 'C' which is the sum of 'A' and 'B'
        df['C'] = df['A'] + df['B']
        return df

    @task
    def print_dataframe(df: pd.DataFrame):
        print("Final DataFrame:\n", df)

    df = create_dataframe()
    manipulated_df = manipulate_dataframe(df)
    print_dataframe(manipulated_df)

example_dag = taskflow_pandas_example()
