from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator

# Define the Python function for each task
def print_hello():
    return 'Hello'

def print_world():
    return 'World'

# Define default arguments for the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 3, 26),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Define the DAG, its scheduling, and default arguments
with DAG('hello_world_dag',
         default_args=default_args,
         description='A simple Hello World DAG',
         schedule_interval=timedelta(days=1),  # This DAG will run daily
         catchup=False) as dag:

    # Define tasks/operators
    start_task = DummyOperator(
        task_id='start'
    )

    hello_task = PythonOperator(
        task_id='hello_task',
        python_callable=print_hello,
    )

    world_task = PythonOperator(
        task_id='world_task',
        python_callable=print_world,
    )

    end_task = DummyOperator(
        task_id='end'
    )

    # Set task dependencies
    start_task >> hello_task >> world_task >> end_task
