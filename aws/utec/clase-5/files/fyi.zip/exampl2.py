from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator

# Default arguments for the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Define the DAG, its schedule, and set it to start in the past
dag = DAG(
    'example_parallel_dag',
    default_args=default_args,
    description='An example DAG that executes tasks in parallel',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2021, 1, 1),
    catchup=False,
)

# Start and end dummy tasks
start_task = DummyOperator(
    task_id='start',
    dag=dag,
)

end_task = DummyOperator(
    task_id='end',
    dag=dag,
)

# Create multiple tasks in parallel
for i in range(15):  # Create 5 parallel tasks
    print("Test")
    task = DummyOperator(
        task_id=f'parallel_task_{i}',
        dag=dag,
    )
    
    # Set the task dependencies to ensure parallel execution
    start_task >> task >> end_task
