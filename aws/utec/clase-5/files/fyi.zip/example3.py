from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
import pandas as pd

# Define Python functions for Airflow tasks
def create_dataframe():
    # Create a DataFrame
    df = pd.DataFrame({
        'A': [1, 2, 3, 4],
        'B': [5, 6, 7, 8]
    })
    return df

def manipulate_dataframe(**kwargs):
    ti = kwargs['ti']
    df = ti.xcom_pull(task_ids='create_dataframe_task')
    # Add a new column 'C' which is the sum of 'A' and 'B'
    df['C'] = df['A'] + df['B']
    ti.xcom_push(key='manipulated_df', value=df)

def print_dataframe(**kwargs):
    ti = kwargs['ti']
    df = ti.xcom_pull(task_ids='manipulate_dataframe_task', key='manipulated_df')
    print("Final DataFrame:\n", df)

# Define the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2021, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'pandas_example_dag',
    default_args=default_args,
    description='A DAG that demonstrates pandas operations',
    schedule_interval=timedelta(days=1),
    catchup=False,
)

# Define tasks
create_dataframe_task = PythonOperator(
    task_id='create_dataframe_task',
    python_callable=create_dataframe,
    dag=dag,
)

manipulate_dataframe_task = PythonOperator(
    task_id='manipulate_dataframe_task',
    python_callable=manipulate_dataframe,
    provide_context=True,
    dag=dag,
)

print_dataframe_task = PythonOperator(
    task_id='print_dataframe_task',
    python_callable=print_dataframe,
    provide_context=True,
    dag=dag,
)

# Set task dependencies
create_dataframe_task >> manipulate_dataframe_task >> print_dataframe_task
