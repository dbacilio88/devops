from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator


def print_hello():
    return 'Hola'

def print_world():
    return 'Mundo'

# Define default arguments for the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 3, 26),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}


with DAG('juan_test',
         default_args=default_args,
         description='Un ejemplo simple',
         schedule_interval='0 5 * * *',  # This DAG will run daily
         catchup=False) as dag:

    start_task = DummyOperator(
        task_id='start'
    )

    hello_task = PythonOperator(
        task_id='hello_task',
        python_callable=print_hello,
    )

    world_task = PythonOperator(
        task_id='world_task',
        python_callable=print_world,
    )

    end_task = DummyOperator(
        task_id='end'
    )

    start_task >> world_task >> end_task
    hello_task >> world_task >> end_task