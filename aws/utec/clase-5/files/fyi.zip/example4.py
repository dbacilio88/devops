from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 3, 26),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'bash_operator_example',
    default_args=default_args,
    description='An example DAG using BashOperator',
    schedule_interval=timedelta(days=1),
)

# Task to create a new directory
create_directory = BashOperator(
    task_id='create_directory',
    bash_command='mkdir -p /tmp/airflow_test_dir',
    dag=dag,
)

# Task to create a file in the new directory
create_file = BashOperator(
    task_id='create_file',
    bash_command='echo "Hello, Airflow!" > /tmp/airflow_test_dir/test_file.txt',
    dag=dag,
)

# Task to list the contents of the directory
list_directory = BashOperator(
    task_id='list_directory',
    bash_command='ls -l /tmp/airflow_test_dir',
    dag=dag,
)


create_directory >> create_file >> list_directory
